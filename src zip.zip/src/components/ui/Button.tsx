import type { ButtonHTMLAttributes } from 'react'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger'
}

const VARIANT_CLASSES: Record<NonNullable<ButtonProps['variant']>, string> = {
  primary: 'bg-brand-blue-700 text-white shadow-sm hover:bg-brand-blue-900 active:bg-navy-900',
  secondary: 'border border-ink-100 bg-white text-ink-700 shadow-sm hover:border-ink-300 hover:bg-ink-50 active:bg-ink-100',
  danger: 'bg-brand-red-500 text-white shadow-sm hover:bg-brand-red-700 active:bg-brand-red-700',
}

// 2026-08-30 "make it bigger" pass: px-4/py-2 (~36px tall) grew to
// px-5/py-3 (~44px tall) with a bigger radius, matching the same
// 44-48px touch-target bump applied to Modal.tsx/FormField.tsx - every
// button in the app routes through this component, so this one change
// covers all of them.
export function Button({ variant = 'primary', className = '', disabled, ...rest }: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-5 py-3 text-sm font-medium transition-all duration-150 disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none active:scale-[0.98] ${VARIANT_CLASSES[variant]} ${className}`}
      disabled={disabled}
      {...rest}
    />
  )
}
